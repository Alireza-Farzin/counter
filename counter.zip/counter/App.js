// Import createApp from Vue to create a Vue application instance
const { createApp } = Vue;

const App = createApp({
    data() {
        return {
            number: 0
        };
    },
    methods: {
        increment() {
            this.number++;
        },
        decrement() {
            if (this.number > 0) {
                this.number--;
            }
        }
    }
});

App.mount('#App');


// import { ref } from 'vue';
// export default {
//   setup() {
//     const number = ref(0);

//     function increment() {
//       number.value++;
//     }
//     function decrement() {
//       number.value--;
//     }
//     return { number, increment, decrement };
//   },
// };